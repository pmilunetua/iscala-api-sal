﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using SavAppi.Models;

namespace SavAppi.Controllers
{
    [Authorize]
    public class CustBalController : ApiController
    {
        
        string connectionString = ConnStrClass.constr;
        // GET: api/CustBalList/{start}/{rowsperpage}
        
        [HttpGet]
        [Route("api/CustBal/GetAll/{id}/{nxt}")]
        public IHttpActionResult GetAllCB(int id, int nxt)
        {
            DataTable dt = new DataTable();

            //int strt = (id * 10) + 1;
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("spCustomerBalance", sqlCon);
                    cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = nxt;
                    cmd.Parameters.Add("@Start", SqlDbType.Int).Value = id;
                    cmd.Parameters.Add("@Custcode", SqlDbType.NVarChar).Value = "";
                    cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "All";
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);


                }

                List<CustBalClass> custBalList = new List<CustBalClass>();
                custBalList = (from DataRow dr in dt.Rows
                             select new CustBalClass()
                             {
                                 Document_Number = Convert.ToInt32(dr["Document_Number"]),
                                 Customer_code = dr["Customer_code"].ToString(),
                                 Balance_amount = Convert.ToDecimal(dr["Balance_amount"]),
                                 DateLastInvoice = Convert.ToDateTime(dr["DateLastInvoice"]),
                                 DateLastPayment = Convert.ToDateTime(dr["DateLastPayment"]),
                                 AmountCreditLimit = Convert.ToDecimal(dr["AmountCreditLimit"])


                             }).ToList();

                return Ok(custBalList);
            }

            catch (Exception ex)
            {
                List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                return Ok(errNt);
            }
        }

        // GET: api/CustBalBy/{custcode}
        [HttpGet]
        [Route("api/CustBal/GetBy/{custcode}")]
        public IHttpActionResult GetOneCB(string custcode)
        {
            DataTable dt = new DataTable();


            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("spCustomerBalance", sqlCon);
                    cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@Start", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@Custcode", SqlDbType.NVarChar).Value = custcode;
                    cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "One";
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);


                }

                List<CustBalClass> custBalList = new List<CustBalClass>();
                custBalList = (from DataRow dr in dt.Rows
                               select new CustBalClass()
                               {
                                   Document_Number = Convert.ToInt32(dr["Document_Number"]),
                                   Customer_code = dr["Customer_code"].ToString(),
                                   Balance_amount = Convert.ToDecimal(dr["Balance_amount"]),
                                   DateLastInvoice = Convert.ToDateTime(dr["DateLastInvoice"]),
                                   DateLastPayment = Convert.ToDateTime(dr["DateLastPayment"]),
                                   AmountCreditLimit = Convert.ToDecimal(dr["AmountCreditLimit"])

                               }).ToList();

                return Ok(custBalList);
            }

            catch (Exception ex)
            {
                List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                return Ok(errNt);
            }
        }
    }
}
