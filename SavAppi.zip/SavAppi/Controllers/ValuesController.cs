﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SavAppi.Models;

namespace SavAppi.Controllers
{
    [Authorize]
    public class ValuesController : ApiController
    {
        string connectionString = ConnStrClass.constr;

        // GET: api/OrderStatus/GetBy/{OrderNo}
        /// <summary>
        /// Order with status
        /// </summary>
        /// <param name="OrderNo"> Order Status</param>
        /// <returns>status json</returns>
        [HttpGet]
        [Route("api/OrderStatus/GetBy/{Order_No}")]
        public IHttpActionResult GetOrderStatus(string Order_No)
        {
            DataTable dtOrderHist = new DataTable();
            DataTable dtOrderCur = new DataTable();
            DataSet ds = new DataSet();
            
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {

                SqlCommand cmd = new SqlCommand("spOrderStatus", sqlCon);
                cmd.Parameters.Add("@OrderNo", SqlDbType.NVarChar).Value = Order_No;
                cmd.CommandType = CommandType.StoredProcedure;
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    dtOrderHist = ds.Tables[0];
                    dtOrderCur = ds.Tables[1];

                }

                catch (Exception ex)
                {
                    List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                    return Ok(errNt);
                }

            }
            List<OrderStatus> orderStu = new List<OrderStatus>();
            DataSet dord = new DataSet();
            if (dtOrderCur.Rows.Count != 0)
            {
                orderStu = (from DataRow dr in dtOrderCur.Rows
                            select new OrderStatus()
                            {
                                OrderNo = Order_No,
                                //Convert.ToInt32(dr["ID"]),
                                TypeID = Convert.ToInt32(dr["OrderTypeID"]),
                                TypeName = dr["OrderType"].ToString(),
                                OrStatus = Convert.ToInt32(dr["StatusID"]),
                                OrStatusName = dr["OrderStatus"].ToString()
                            }).ToList();
            }
            else if ((dtOrderCur.Rows.Count == 0) && (dtOrderHist.Rows.Count != 0))
            {
                orderStu = (from DataRow dr in dtOrderHist.Rows
                            select new OrderStatus()
                            {
                                OrderNo = Order_No,
                                //Convert.ToInt32(dr["ID"]),
                                TypeID = 1,
                                TypeName = "Invoiced",
                                OrStatus = 1,
                                OrStatusName = "InvNo: " + dr["InvoiceNo"].ToString()
                            }).ToList();

            }
            else
            {
                orderStu = (from DataRow dr in dtOrderCur.Rows
                            select new OrderStatus()
                            {
                                OrderNo = Order_No,
                                //Convert.ToInt32(dr["ID"]),
                                TypeID = 0,
                                TypeName = Order_No + " not found",
                                OrStatus = 0,
                                OrStatusName = ""
                            }).ToList();

            }
           
            
            return Ok(orderStu);
        }
        // GET: api/Customer/{custcode}
        /// <summary>
        /// Order with order lines 
        /// </summary>
        /// <param name="CustOrder"> Customer Order Number</param>
        /// <returns>nested json</returns>
        [HttpGet]
        [Route("api/OrdersWithLines/GetBy/{CustOrder}")]
        public IHttpActionResult GetOneCust(string CustOrder)
        {
            DataTable dtOrder = new DataTable();
            DataTable dtLines = new DataTable();
            DataSet ds = new DataSet();

            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {

                SqlCommand cmd = new SqlCommand("spCustOrdersAndLines", sqlCon);
                cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 0;
                cmd.Parameters.Add("@Start", SqlDbType.Int).Value = 0;
                cmd.Parameters.Add("@OrderNo", SqlDbType.NVarChar).Value = CustOrder;
                cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "mo";
                cmd.CommandType = CommandType.StoredProcedure;
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    dtOrder = ds.Tables[0];
                    dtLines =  ds.Tables[1];

                }

                catch (Exception ex)
                {
                    List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                    return Ok(errNt);
                }

            }

            List<CustOrder> orderList = new List<CustOrder>();
            orderList = (from DataRow dr in dtOrder.Rows
                        select new CustOrder()
                        {
                            User_code = dr["User_code"].ToString(),
                             //Convert.ToInt32(dr["ID"]),
                            Customer_code = dr["Customer_code"].ToString(),
                            CustomerName = dr["CustomerName"].ToString(),
                            Lpo_number = dr["Lpo_number"].ToString(),
                            Transaction_id = dr["Transaction_id"].ToString(),
                            InvoiceNo = dr["InvoiceNo"].ToString()
                        }).ToList();
                        foreach (var d in orderList)
                        {
                            var a = GetOrderLines(d.Transaction_id, dtLines);
                            d.Orderlines = a;
                        }
            return Ok(orderList);


        }

        private List<Orderline> GetOrderLines (string orderno, DataTable dtLines)
        {
            
            List<Orderline> OrderLines = new List<Orderline>();
            OrderLines = (from DataRow dr in dtLines.Rows
                             select new Orderline()
                             {
                                 CustOrder_id = dr["OrderNo"].ToString(),
                                 IntrPlanning = Convert.ToDateTime(dr["IntrPlanning"]),
                                 Item_code = dr["Item_code"].ToString(),
                                 Price_exc_vat = Convert.ToDecimal(dr["Price_exc_vat"]),
                                 Warehouse_code = dr["Warehouse_code"].ToString(),
                                 Quantity = Convert.ToDecimal(dr["Quantity"]),
                                 Line_No = dr["Line_No"].ToString(),
                                 DescripLine1 = dr["DescripLine1"].ToString(),
                                 VATCode1099 = Convert.ToInt32(dr["VATCode1099"]),
                                 SellPrMultip = Convert.ToInt32(dr["SellPrMultip"])
                             }).ToList();

            return OrderLines;
        }

        /// <summary>
        /// All Order with order lines 
        /// </summary>
        /// <param name="pge"> Page number of the Order with lines</param>
        /// <returns>nested json</returns>
        [HttpGet]
        [Route("api/OrdersWithLines/GetAllBy/{pge}")]
        public IHttpActionResult GetAllOrderAndLines(int pge)
        {
            DataTable dtOrder = new DataTable();
            DataTable dtLines = new DataTable();
            DataSet ds = new DataSet();
            int strt = 0;
            strt = pge <= 0 ? 1 : ((pge - 1) * 100) + 1;

            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {

                SqlCommand cmd = new SqlCommand("spCustOrdersAndLines", sqlCon);
                cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 100;
                cmd.Parameters.Add("@Start", SqlDbType.Int).Value = strt;
                cmd.Parameters.Add("@OrderNo", SqlDbType.NVarChar).Value = "";
                cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "Tst"; //All
                cmd.CommandType = CommandType.StoredProcedure;
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    dtOrder = ds.Tables[0];
                    dtLines = ds.Tables[1];
                }

                catch (Exception ex)
                {
                    List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                    return Ok(errNt);
                }

            }

            List<CustOrder> orderList = new List<CustOrder>();
             orderList = (from DataRow dr in dtOrder.Rows
                         select new CustOrder()
                         {
                             User_code = dr["User_code"].ToString(),
                             //Convert.ToInt32(dr["ID"]),
                             Customer_code = dr["Customer_code"].ToString(),
                             CustomerName = dr["CustomerName"].ToString(),
                             Lpo_number = dr["Lpo_number"].ToString(),
                             Transaction_id = dr["Transaction_id"].ToString(),
                             InvoiceNo = dr["InvoiceNo"].ToString()
                         }).ToList();
                        foreach (var d in orderList)
                        {
                            string _sqlWhere = "OrderNo = " + d.Transaction_id ; //orderno;
                            string _sqlOrder = "Line_No";
                            DataRow[] filteredDt;
                            filteredDt = dtLines.Select(_sqlWhere, _sqlOrder);
                            if (filteredDt.Length == 0)
                            {
                                d.Orderlines = null;
                            }
                            else
                            {
                                var a = orderRowLines(d.Transaction_id, filteredDt);
                                d.Orderlines = a;
                            }
                        }
                        return Ok(orderList);
        }
        private List<Orderline> orderRowLines(string orderno, DataRow[] dtLines)
        {
            List<Orderline> OrderLines = new List<Orderline>();
            OrderLines = (from DataRow dr in dtLines
                          select new Orderline()
                          {
                              CustOrder_id = dr["OrderNo"].ToString(),
                              IntrPlanning = Convert.ToDateTime(dr["IntrPlanning"]),
                              Item_code = dr["Item_code"].ToString(),
                              Price_exc_vat = Convert.ToDecimal(dr["Price_exc_vat"]),
                              Warehouse_code = dr["Warehouse_code"].ToString(),
                              Quantity = Convert.ToDecimal(dr["Quantity"]),
                              Line_No = dr["Line_No"].ToString(),
                              DescripLine1 = dr["DescripLine1"].ToString(),
                              VATCode1099 = Convert.ToInt32(dr["VATCode1099"]),
                              SellPrMultip = Convert.ToInt32(dr["SellPrMultip"])
                          }).ToList();
            return OrderLines;
        }
    }
}
