﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using SavAppi.Models;
using System.Configuration;

namespace SavAppi.Controllers
{
    [Authorize]
    public class WhseBalController : ApiController
    {
        string connectionString =  ConnStrClass.constr;

        // GET: api/WhseBal/{start}/{rowsperpage}
        [HttpGet]
        [Route("api/WhseBal/GetByPage/{id}/{nxt}")]
        public IHttpActionResult GetAllWB(int id, int nxt)
        {
            DataTable dt = new DataTable();

            //int strt = (id * 10) + 1;
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("spItemWhseBalance", sqlCon);
                    cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = nxt;
                    cmd.Parameters.Add("@Start", SqlDbType.Int).Value = id;
                    cmd.Parameters.Add("@Prodcode", SqlDbType.NVarChar).Value = "";
                    cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "All";
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);


                }

                List<WhseBalClass> itemWBList = new List<WhseBalClass>();
                itemWBList = (from DataRow dr in dt.Rows
                             select new WhseBalClass()
                             {
                                 Warehouse_Code = dr["Warehouse_Code"].ToString(),
                                 Item_code = dr["Item_code"].ToString(),
                                 Item_name = dr["Item_name"].ToString(),
                                 Batch_number = dr["Batch_number"].ToString(),
                                 Quantity    = Convert.ToDecimal(dr["Quantity"])
                                 
                             }).ToList();

                return Ok(itemWBList);
            }

            catch (Exception ex)
            {
                List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                return Ok(errNt);
            }
        }
        // GET: api/WhseBal/{start}/{rowsperpage}
        [HttpGet]
        [Route("api/WhseBal/GetAllin/{Whse}")]
        public IHttpActionResult GetAllin(string Whse)
        {
            DataTable dt = new DataTable();

            //int strt = (id * 10) + 1;
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("spItemWhseBalance", sqlCon);
                    cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@Start", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@Prodcode", SqlDbType.NVarChar).Value = "";
                    cmd.Parameters.Add("@Whse", SqlDbType.NVarChar).Value = Whse;
                    cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "AllInWhse";
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);


                }

                List<WhseBalClass> itemWBList = new List<WhseBalClass>();
                itemWBList = (from DataRow dr in dt.Rows
                              select new WhseBalClass()
                              {
                                  Warehouse_Code = dr["Warehouse_Code"].ToString(),
                                  Item_code = dr["Item_code"].ToString(),
                                  Item_name = dr["Item_name"].ToString(),
                                  Batch_number = dr["Batch_number"].ToString(),
                                  Quantity = Convert.ToDecimal(dr["Quantity"])

                              }).ToList();

                return Ok(itemWBList);
            }

            catch (Exception ex)
            {
                List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                return Ok(errNt);
            }
        }
        // GET: api/WhseBal/{Itemcode}
        [HttpGet]
        [Route("api/WhseBal/GetBy/{Itemcode}")]
        public IHttpActionResult GetOneWB(string Itemcode)
        {
            DataTable dt = new DataTable();


            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("spItemWhseBalance", sqlCon);
                    cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@Start", SqlDbType.NVarChar).Value = 0;
                    cmd.Parameters.Add("@Prodcode", SqlDbType.NVarChar).Value = Itemcode;
                    cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "One";
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);


                }

                List<WhseBalClass> itemWBList = new List<WhseBalClass>();
                itemWBList = (from DataRow dr in dt.Rows
                              select new WhseBalClass()
                              {
                                  Warehouse_Code = dr["Warehouse_Code"].ToString(),
                                  Item_code = dr["Item_code"].ToString(),
                                  Item_name = dr["Item_name"].ToString(),
                                  Batch_number = dr["Batch_number"].ToString(),
                                  Quantity = Convert.ToDecimal(dr["Quantity"])

                              }).ToList();

                return Ok(itemWBList);
            }

            catch (Exception ex)
            {
                List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                return Ok(errNt);
            }
        }
        // GET: api/WhseBal/{Itemcode}
        [HttpGet]
        [Route("api/WhseBal/GetBy/{Itemcode}/{Whse}")]
        public IHttpActionResult GetOneWB(string Itemcode, string Whse)
        {
            DataTable dt = new DataTable();


            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("spItemWhseBalance", sqlCon);
                    cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@Start", SqlDbType.Int).Value = 0 ;
                    cmd.Parameters.Add("@Whse", SqlDbType.NVarChar).Value = Whse;
                    cmd.Parameters.Add("@Prodcode", SqlDbType.NVarChar).Value = Itemcode;
                    cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "Whse";
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);


                }

                List<WhseBalClass> itemWBList = new List<WhseBalClass>();
                itemWBList = (from DataRow dr in dt.Rows
                              select new WhseBalClass()
                              {
                                  Warehouse_Code = dr["Warehouse_Code"].ToString(),
                                  Item_code = dr["Item_code"].ToString(),
                                  Item_name = dr["Item_name"].ToString(),
                                  Batch_number = dr["Batch_number"].ToString(),
                                  Quantity = Convert.ToDecimal(dr["Quantity"])

                              }).ToList();

                return Ok(itemWBList);
            }

            catch (Exception ex)
            {
                List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                return Ok(errNt);
            }
        }
    }
}
