﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using SavAppi.Models;

namespace SavAppi.Controllers
{
    [Authorize]
    public class ItemMasterController : ApiController
    {
        string connectionString = ConnStrClass.constr;

        // GET: api/ItemMaster/GetByPage/{id}/{rows}
        [HttpGet]
        [Route("api/ItemMaster/GetByPage/{id}/{rows}")]
        public IHttpActionResult GetAllItems(int id, int rows)
        {
            DataTable dt = new DataTable();

            //int strt = id <= 0 ? 1 : ((id - 1) * 10) + 1; 
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {

                SqlCommand cmd = new SqlCommand("spItemMaster", sqlCon);
                cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = rows;
                cmd.Parameters.Add("@Start", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@Prodcode", SqlDbType.NVarChar).Value = "";
                cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "All";
                cmd.CommandType = CommandType.StoredProcedure;
               
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                

            }

            List<ItemMasterClass> itemList = new List<ItemMasterClass>();
            itemList = (from DataRow dr in dt.Rows
                        select new ItemMasterClass()
                        {
                            PRODUCTCODE = dr["PRODUCTCODE"].ToString(),//
                            CATEGORY_NAME = dr["CATEGORY_NAME"].ToString(),
                            BRANDNAME = dr["BRANDNAME"].ToString(),
                            PRODUCTDESCRIPTION = dr["PRODUCTDESCRIPTION"].ToString(),
                            UOM = dr["UOM"].ToString(),
                            TAXCODE = dr["TAXCODE"].ToString(),
                            RSPAMOUNT = Convert.ToDecimal(dr["RSPAMOUNT"]), //  decimal
                            CARTONMINPRICE = Convert.ToDecimal(dr["CARTONMINPRICE"]),
                            SKUMINPRICE = Convert.ToDecimal(dr["SKUMINPRICE"]),
                            WEIGHTUOM = Convert.ToDecimal(dr["WEIGHTUOM"]),
                            WEIGHT = Convert.ToDecimal(dr["WEIGHT"]),
                            CARTON_QUANTITY = Convert.ToInt32(dr["CARTON_QUANTITY"]),
                            POST_FLAG = dr["POST_FLAG"].ToString(),
                            POST_DATE = Convert.ToDateTime(dr["POST_DATE"]), // DateTime

                            Volume = Convert.ToDecimal(dr["Volume"]),
                            ItemsPerPackageSales = Convert.ToInt32(dr["ItemsPerPackageSales"]),
                            AccCodeStrg = dr["AccCodeStrg"].ToString()

                        }).ToList();

            return Ok(itemList);
            }

            catch (Exception ex)
            {
                List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                return Ok(errNt);
            }
        }
        // GET: api/ItemMaster/GetAll
        [HttpGet]
        [Route("api/ItemMaster/GetAll")]
        public IHttpActionResult GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("spItemMaster", sqlCon);
                    cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@Start", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@Prodcode", SqlDbType.NVarChar).Value = "";
                    cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "Any";
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);


                }

                List<ItemMasterClass> itemList = new List<ItemMasterClass>();
                itemList = (from DataRow dr in dt.Rows
                            select new ItemMasterClass()
                            {
                                PRODUCTCODE = dr["PRODUCTCODE"].ToString(),//
                                CATEGORY_NAME = dr["CATEGORY_NAME"].ToString(),
                                BRANDNAME = dr["BRANDNAME"].ToString(),
                                PRODUCTDESCRIPTION = dr["PRODUCTDESCRIPTION"].ToString(),
                                UOM = dr["UOM"].ToString(),
                                TAXCODE = dr["TAXCODE"].ToString(),
                                RSPAMOUNT = Convert.ToDecimal(dr["RSPAMOUNT"]), //  decimal
                                CARTONMINPRICE = Convert.ToDecimal(dr["CARTONMINPRICE"]),
                                SKUMINPRICE = Convert.ToDecimal(dr["SKUMINPRICE"]),
                                WEIGHTUOM = Convert.ToDecimal(dr["WEIGHTUOM"]),
                                WEIGHT = Convert.ToDecimal(dr["WEIGHT"]),
                                CARTON_QUANTITY = Convert.ToInt32(dr["CARTON_QUANTITY"]),
                                POST_FLAG = dr["POST_FLAG"].ToString(),
                                POST_DATE = Convert.ToDateTime(dr["POST_DATE"]), // DateTime

                                Volume = Convert.ToDecimal(dr["Volume"]),
                                ItemsPerPackageSales = Convert.ToInt32(dr["ItemsPerPackageSales"]),
                                AccCodeStrg = dr["AccCodeStrg"].ToString()

                            }).ToList();

                return Ok(itemList);
            }

            catch (Exception ex)
            {
                List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                return Ok(errNt);
            }
        }
        // GET: api/ItemMaster7/GetBy/{Itemcode}
        [HttpGet]
        [Route("api/ItemMaster/GetBy/{Itemcode}")]
        public IHttpActionResult GetOneItem(string Itemcode)
        {
            DataTable dt = new DataTable();

            
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("spItemMaster", sqlCon);
                    cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@Start", SqlDbType.Int).Value = 0;
                    cmd.Parameters.Add("@Prodcode", SqlDbType.NVarChar).Value = Itemcode;
                    cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "One";
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);


                }

                List<ItemMasterClass> itemList = new List<ItemMasterClass>();
                itemList = (from DataRow dr in dt.Rows
                            select new ItemMasterClass()
                            {
                                PRODUCTCODE = dr["PRODUCTCODE"].ToString(),//
                                CATEGORY_NAME = dr["CATEGORY_NAME"].ToString(),
                                BRANDNAME = dr["BRANDNAME"].ToString(),
                                PRODUCTDESCRIPTION = dr["PRODUCTDESCRIPTION"].ToString(),
                                UOM = dr["UOM"].ToString(),
                                TAXCODE = dr["TAXCODE"].ToString(),
                                RSPAMOUNT = Convert.ToDecimal(dr["RSPAMOUNT"]), //  decimal
                                CARTONMINPRICE = Convert.ToDecimal(dr["CARTONMINPRICE"]),
                                SKUMINPRICE = Convert.ToDecimal(dr["SKUMINPRICE"]),
                                WEIGHTUOM = Convert.ToDecimal(dr["WEIGHTUOM"]),
                                WEIGHT = Convert.ToDecimal(dr["WEIGHT"]),
                                CARTON_QUANTITY = Convert.ToInt32(dr["CARTON_QUANTITY"]),
                                POST_FLAG = dr["POST_FLAG"].ToString(),
                                POST_DATE = Convert.ToDateTime(dr["POST_DATE"]), // DateTime

                                Volume = Convert.ToDecimal(dr["Volume"]),
                                ItemsPerPackageSales = Convert.ToInt32(dr["ItemsPerPackageSales"]),
                                AccCodeStrg = dr["AccCodeStrg"].ToString()

                            }).ToList();

                return Ok(itemList);
            }

            catch (Exception ex)
            {
                List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                return Ok(errNt);
            }
        }
    }
}
