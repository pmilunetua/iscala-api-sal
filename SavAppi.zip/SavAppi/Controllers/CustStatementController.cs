﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SavAppi.Models;

namespace SavAppi.Controllers
{
    [Authorize]
    public class CustStatementController : ApiController
    {
        string connectionString = ConnStrClass.constr;

        // GET: api/ CustStatement/{custcode}
        /// <summary>
        /// Customer with outstanding invoice lines 
        /// </summary>
        /// <param name="CustOrder"> Customer ID</param>
        /// <returns>nested json</returns>
        [HttpGet]
        [Route("api/CustStatement/GetBy/{Custcode}")]
        public IHttpActionResult GetOneCust(string Custcode)
        {
            DataTable dtCust = new DataTable();
           
            DataSet ds = new DataSet();

            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {

                SqlCommand cmd = new SqlCommand("spCustOutandingInvoices", sqlCon);
                cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 0;
                cmd.Parameters.Add("@Start", SqlDbType.Int).Value = 0;
                cmd.Parameters.Add("@Custcode", SqlDbType.NVarChar).Value = Custcode;
                cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "mo";
                cmd.CommandType = CommandType.StoredProcedure;
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    dtCust = ds.Tables[0];
                   

                }

                catch (Exception)
                {
                    throw;
                }

            }

            List<CustStatement> custStmnt = new List<CustStatement>();
            custStmnt = (from DataRow dr in dtCust.Rows
                         select new CustStatement()
                         {
                             Customer_code = dr["Customer_code"].ToString(),
                             Customer_name = dr["Customer_name"].ToString(),
                             Document_Number = dr["InvoiceNo"].ToString(),
                             InvoiceDate = Convert.ToDateTime(dr["InvoiceDate"]),
                             DueDate = Convert.ToDateTime(dr["DueDate"]),
                             InvAmount = Convert.ToDecimal(dr["InvAmoLocCur"]),
                             TotPaydAmount = Convert.ToDecimal(dr["TotPaydAmLCU"]),
                             DateLastPayment = Convert.ToDateTime(dr["LastPaymDate"]),
                             Balance_amount = Convert.ToDecimal(dr["Balance_amount"])

                         }).ToList();

            return Ok(custStmnt);
            
        }

        

        // GET: api/CustStatement/{custcode}
        /// <summary>
        /// Customer with outstanding invoice lines 
        /// </summary>
        /// <param name="pge"> pages to call</param>
        /// <returns>nested json</returns>
        [HttpGet]
        [Route("api/CustStatement/GetAllBy/{pge}")]
        public IHttpActionResult GetOutstandingInvLines(int pge)
        {
            DataTable dtCust = new DataTable();
            DataSet ds = new DataSet();
            int strt = 0;
            strt = pge <= 0 ? 1 : ((pge - 1) * 10) + 1;

            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {

                SqlCommand cmd = new SqlCommand("spCustOutandingInvoices", sqlCon);
                cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 5;
                cmd.Parameters.Add("@Start", SqlDbType.Int).Value = strt;
                cmd.Parameters.Add("@Custcode", SqlDbType.NVarChar).Value = "";
                cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "All";
                cmd.CommandType = CommandType.StoredProcedure;
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    dtCust = ds.Tables[0];
                }

                catch (Exception ex)
                {
                   // var  e = new Tuple<string, string>("An Error has occured!", ex.Message);
                  List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                    return Ok(errNt);
                }

            }

            List<CustStatement> custStmnt = new List<CustStatement>();
            custStmnt = (from DataRow dr in dtCust.Rows
                        select new CustStatement()
                        {
                            Customer_code = dr["Customer_code"].ToString(),
                            Customer_name = dr["Customer_name"].ToString(),
                            Document_Number = dr["InvoiceNo"].ToString(),
                            InvoiceDate = Convert.ToDateTime(dr["InvoiceDate"]),
                            DueDate = Convert.ToDateTime(dr["DueDate"]),
                            InvAmount = Convert.ToDecimal(dr["InvAmoLocCur"]),
                            TotPaydAmount = Convert.ToDecimal(dr["TotPaydAmLCU"]),
                            DateLastPayment = Convert.ToDateTime(dr["LastPaymDate"]),
                            Balance_amount = Convert.ToDecimal(dr["Balance_amount"])

                        }).ToList();
            
            return Ok(custStmnt);
        }

       
    }
}
