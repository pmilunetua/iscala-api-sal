﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SavAppi.Models;

namespace SavAppi.Controllers
{
    
    public class CustomerController : ApiController
    {
        string connectionString = ConnStrClass.constr;

        // GET: api/Customer/{custcode}
        [HttpGet]
        [Route("api/Customer/GetBy/{custcode}")]
        public IHttpActionResult GetOneCust(string custcode)
        {
            DataTable dt = new DataTable();

            
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("spCustomerMaster", sqlCon);
                    cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 5;
                    cmd.Parameters.Add("@Start", SqlDbType.Int).Value = 3;
                    cmd.Parameters.Add("@Custcode", SqlDbType.NVarChar).Value = custcode;
                    cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "mo";
                    cmd.CommandType = CommandType.StoredProcedure;
                    try
                    {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    }
                
                    catch (Exception ex)
                    {
                    List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                    return Ok(errNt);
                }

                }

                List<CustomerClass> custList = new List<CustomerClass>();
                custList = (from DataRow dr in dt.Rows
                            select new CustomerClass()
                            {
                                ID = Convert.ToInt32(dr["ID"]),
                                CUSCODE = dr["CUSCODE"].ToString(),
                                CUSTOMERNAME = dr["CUSTOMERNAME"].ToString(),
                                CUSTOMERGROUP = dr["CUSTOMERGROUP"].ToString(),
                                AddressLine1 = dr["AddressLine1"].ToString()
                            }).ToList();

                return Ok(custList);
                

        }
        /// <summary>
        /// Get Customers by navigating a page of 5 records
        /// </summary>
        /// <param name="id">The page number</param>
        /// <returns>What does it return</returns>
        // GET: api/Customer/{custcode}
        [Authorize]
        [HttpGet]
        [Route("api/Customer/GetFromPage/{id}")]
        
        public IHttpActionResult GetAllCust(int id)
        {
            DataTable dt = new DataTable();
            int strt = 0;
            strt = id <= 0 ? 1 :  ((id-1) * 5) + 1;
           
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {

                SqlCommand cmd = new SqlCommand("spCustomerMaster", sqlCon);
                cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 5;
                cmd.Parameters.Add("@Start", SqlDbType.Int).Value = strt;
                cmd.Parameters.Add("@Custcode", SqlDbType.NVarChar).Value = "";
                cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "All";
                cmd.CommandType = CommandType.StoredProcedure;
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                catch (Exception ex)
                {
                    List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                    return Ok(errNt);
                }

            }

            List<CustomerClass> custList = new List<CustomerClass>();
            custList = (from DataRow dr in dt.Rows
                        select new CustomerClass()
                        {
                            ID = Convert.ToInt32(dr["ID"]),
                            CUSCODE = dr["CUSCODE"].ToString(),
                            CUSTOMERNAME = dr["CUSTOMERNAME"].ToString(),
                            CUSTOMERGROUP = dr["CUSTOMERGROUP"].ToString(),
                            AddressLine1 = dr["AddressLine1"].ToString()
                        }).ToList();

            return Ok(custList);


        }
        // GET: api/Customer/GetAll
        [Authorize]
        [HttpGet]
        [Route("api/Customer/GetAll")]

        public IHttpActionResult GetAll()
        {
            DataTable dt = new DataTable();
           

            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {

                SqlCommand cmd = new SqlCommand("spCustomerMaster", sqlCon);
                cmd.Parameters.Add("@Limit", SqlDbType.Int).Value = 0;
                cmd.Parameters.Add("@Start", SqlDbType.Int).Value = 0;
                cmd.Parameters.Add("@Custcode", SqlDbType.NVarChar).Value = "";
                cmd.Parameters.Add("@Option", SqlDbType.NVarChar).Value = "Any";
                cmd.CommandType = CommandType.StoredProcedure;
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                catch (Exception ex)
                {
                    List<errMsg> errNt = new List<errMsg>
                    {
                        new errMsg(){ errNote = "An Error has occured!",errMessage = ex.Message }
                    };
                    return Ok(errNt);
                }

            }

            List<CustomerClass> custList = new List<CustomerClass>();
            custList = (from DataRow dr in dt.Rows
                        select new CustomerClass()
                        {
                            ID = Convert.ToInt32(dr["ID"]),
                            CUSCODE = dr["CUSCODE"].ToString(),
                            CUSTOMERNAME = dr["CUSTOMERNAME"].ToString(),
                            CUSTOMERGROUP = dr["CUSTOMERGROUP"].ToString(),
                            AddressLine1 = dr["AddressLine1"].ToString()
                        }).ToList();

            return Ok(custList);


        }
    }
}
