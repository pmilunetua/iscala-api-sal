﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SavAppi.Models
{
    public class ItemMasterClass
    {
        public string PRODUCTCODE { get; set; }
        public string CATEGORY_NAME { get; set; }
        public string BRANDNAME { get; set; }
        public string PRODUCTDESCRIPTION { get; set; }
        public string UOM { get; set; }
        public string TAXCODE { get; set; }
        public decimal RSPAMOUNT { get; set; }
        public decimal CARTONMINPRICE { get; set; }
        public decimal SKUMINPRICE { get; set; }
        public decimal WEIGHTUOM { get; set; }
        public decimal WEIGHT { get; set; }
        public int CARTON_QUANTITY { get; set; }
        public string POST_FLAG { get; set; }
        public DateTime POST_DATE { get; set; }
        public decimal Volume { get; set; }
        public int ItemsPerPackageSales { get; set; }
        public string AccCodeStrg { get; set; }
    }
}