﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SavAppi.Models
{
    public class CustomerClass
    {
        public int ID { get; set; }
        public string CUSCODE { get; set; }
        public string CUSTOMERNAME { get; set; }
        public string CUSTOMERGROUP { get; set; }
        public string AddressLine1 { get; set; }
        /*
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string EMAILADDRESS { get; set; }
        public string PHONENUMBER { get; set; }
        public string CONTACTPERSON { get; set; }
        public string COUNTRY { get; set; }
        public string REGION { get; set; }
        public string TERRITORY { get; set; }
        public string PAYMENTMODES { get; set; }
        public string CREDITDAYS { get; set; }
        public string VATNO { get; set; }
        public string ACCSTATUS { get; set; }
        public string PRICELIST_NAME { get; set; }
        public string POST_DATE { get; set; }
        public string Category { get; set; }
        public string RegionCode { get; set; }
        public decimal AmountCreditLimit { get; set; }
        public int TaxLiabilityFlag { get; set; }
        public string TAXCode2 { get; set; }
        */
    }
}