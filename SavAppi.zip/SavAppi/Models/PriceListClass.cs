﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SavAppi.Models
{
    public class PriceListClass
    {
        public string PRICE_LIST_NAME { get; set; }
        public decimal PRICE { get; set; }
        public string ITEM_CODE { get; set; }
        public string ITEM_name { get; set; }
        public int POST_FLAG { get; set; }
        public DateTime POST_DATE { get; set; }

    }
}