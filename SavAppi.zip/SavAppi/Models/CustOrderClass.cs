﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SavAppi.Models
{
    public class CustOrder
    {
        public string User_code { get; set; }
        public string Customer_code { get; set; }
        public string CustomerName { get; set; }
        public string Lpo_number { get; set; }
        public string Transaction_id { get; set; }
        public string InvoiceNo { get; set; }

        public virtual ICollection<Orderline> Orderlines { get; set; }

    }

    public class Orderline
    {
        public string CustOrder_id { get; set; }
        public DateTime IntrPlanning { get; set; }
        public string Item_code { get; set; }
        public Decimal Price_exc_vat { get; set; }
        public string Warehouse_code { get; set; }
        public decimal Quantity { get; set; }
        public string Line_No { get; set; }
        public string DescripLine1 { get; set; }
        public int VATCode1099 { get; set; }
        public decimal SellPrMultip { get; set; }
    }
    public class OrderStatus
    {
        public string OrderNo { get; set; }
        public int TypeID { get; set; }
        public string TypeName { get; set; }
        public int OrStatus { get; set; }
        public string OrStatusName { get; set; }
        
    }
}