﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SavAppi.Models
{
    public class CustBalClass
    {
        public int Document_Number { get; set; }
        public string Customer_code { get; set; }
        public decimal Balance_amount { get; set; }
        public DateTime DateLastInvoice { get; set; }
        public DateTime DateLastPayment { get; set; }
        public decimal AmountCreditLimit { get; set; }

    }

    public class CustStatement
    {
        public string Customer_code { get; set; }
        public string Customer_name { get; set; }
        public string Document_Number { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime DueDate { get; set; }
        public decimal InvAmount { get; set; }
        public decimal TotPaydAmount { get; set; }
        public DateTime DateLastPayment { get; set; }
        public decimal Balance_amount { get; set; }
    }
    public class errMsg
    {
        public string errNote { get; set; }
        public string errMessage { get; set; }
    }
    }