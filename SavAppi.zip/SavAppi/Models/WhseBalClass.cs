﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SavAppi.Models
{
    public class WhseBalClass
    {
        public string Warehouse_Code { get; set; }
        public string Item_code { get; set; }
        public string Item_name { get; set; }
        public string Batch_number { get; set; }
        public decimal Quantity { get; set; }

    }
}