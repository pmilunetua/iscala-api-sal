﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Configuration;

namespace SavAppi.Models
{
    public class ConnStrClass
    {
        // declarations  SolutecDB
        public static string constr = ConfigurationManager.ConnectionStrings["SolutecDB"].ConnectionString;

        //public static string constr = @"Data Source = DESKTOP-BUP23R0\SQLEXPRESS; Initial Catalog = Solutec;  User ID=Steam;Password=St34m%2020";

         public static bool login(string username, string password)
        {
           
        Int32 founduser = 0;
            string sql =
                "Select count(*) from utokens where username = @username  "
                + " and password = @password";
            using (SqlConnection conn = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.Add("@username", SqlDbType.VarChar);
                cmd.Parameters["@username"].Value = username;
                cmd.Parameters.Add("@password", SqlDbType.VarChar);
                cmd.Parameters["@password"].Value = password;
                try
                {
                    conn.Open();
                    founduser = (Int32)cmd.ExecuteScalar();
                }
                catch (Exception )
                {
                    throw ; // ex.Message;
                }
            }
            if (founduser > 0) { 
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}